// Sound output menu
// Sound input menu
// Bluetooth
// Wifi
// VPN
// Power mode (detailed?)
// Wired
// Hide item from...

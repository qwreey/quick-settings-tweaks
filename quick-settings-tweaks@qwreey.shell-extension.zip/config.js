export default {
    isDevelopmentBuild: false,
    isReleaseBuild: false,
    isGithubBuild: true,
    version: "2.1-pre7",
    buildNumber: 7,
    baseGTypeName: "quick-settings-tweaks_",
    loggerPrefix: "[quick-settings-tweaks]",
};
